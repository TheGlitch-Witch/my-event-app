import { kv } from "@vercel/kv";
export default async function handler(req, res){
  if (req.query.pass !== process.env.ADMIN_PASS) return res.status(401).json({ error:"unauthorized" });
  const codes = await kv.zrange("rsvp:index", 0, -1, { rev:true });
  const rows = await Promise.all(codes.map(c => kv.get(`rsvp:${c}`)));
  res.json(rows.filter(Boolean));
}

