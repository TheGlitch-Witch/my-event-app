import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const { pass, code, field } = req.body || {};
  if (pass !== process.env.ADMIN_PASS) return res.status(401).json({ error: "unauthorized" });
  if (!["attended","claimed"].includes(field)) return res.status(400).json({ error: "bad field" });
  const rec = await kv.get(`rsvp:${code}`); if (!rec) return res.status(404).json({ error: "not found" });
  rec[field] = !rec[field];
  rec[`${field}_ts`] = rec[field] ? new Date().toISOString() : null;
  await kv.set(`rsvp:${code}`, rec);
  res.json({ ok: true, [field]: rec[field] });
}
