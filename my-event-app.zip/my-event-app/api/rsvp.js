import { kv } from "@vercel/kv";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  const r = req.body || {};
  if (!r.code || !r.name || !r.discord) return res.status(400).json({ error: "bad input" });
  await kv.set(`rsvp:${r.code}`, r);
  await kv.zadd("rsvp:index", { score: Date.now(), member: r.code });
  res.json({ ok: true });
}
