export function Label({ children }) {
  return <label className="block text-sm mb-1">{children}</label>
}
