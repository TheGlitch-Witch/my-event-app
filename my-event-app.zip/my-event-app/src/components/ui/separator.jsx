export function Separator() {
  return <hr className="my-2" />
}
